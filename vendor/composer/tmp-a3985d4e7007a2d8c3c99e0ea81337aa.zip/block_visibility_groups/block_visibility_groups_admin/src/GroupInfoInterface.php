<?php

namespace Drupal\block_visibility_groups_admin;

/**
 * Interface GroupInfoInterface.
 *
 * @package Drupal\block_visibility_groups_admin
 */
interface GroupInfoInterface {


}
