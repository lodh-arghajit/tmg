<?php

namespace Drupal\feeds\Exception;

use RuntimeException;

/**
 * Base class for Feeds runtime exceptions.
 */
abstract class FeedsRuntimeException extends RuntimeException {}
