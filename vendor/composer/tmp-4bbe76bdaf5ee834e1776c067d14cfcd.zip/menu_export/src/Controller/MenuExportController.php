<?php

namespace Drupal\menu_export\Controller;

use Drupal\Core\Controller\ControllerBase;


/**
 * save and send notifications based on user settings.
 */
class MenuExportController extends ControllerBase {
    public function menuExport(){
        
    }
    
    public function menuImport(){
        return ['#markup'=>'dasbdsabdk'];
        
    }
}
