<?php

namespace Drupal\tamper;

use Drupal\Component\Plugin\CategorizingPluginManagerInterface;

/**
 * Interface for Tamper plugin manager.
 */
interface TamperManagerInterface extends CategorizingPluginManagerInterface {
}
