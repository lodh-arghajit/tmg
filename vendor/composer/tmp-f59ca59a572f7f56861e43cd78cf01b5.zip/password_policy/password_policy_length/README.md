password_policy_length
===============

Password Policy Length Drupal Module

Implements a plugin for a Password Policy constraint
