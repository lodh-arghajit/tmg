password_policy_username
========================

Password Policy Username Drupal module

Implements a plugin for a Password Policy constraint, preventing users from
having their username as part of their password.
